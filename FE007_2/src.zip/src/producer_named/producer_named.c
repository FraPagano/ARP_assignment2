/* LIBRARIES */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include "../parameters/parameters.h"
#include "../timing/timing.c"

/* MAIN */
int main(int argc, char *argv[])
{
    int fd;          // File descriptor.
    int data[MAX];   // Array of data to send.

    int noelement_to_send = atoi(argv[1]);   // The number of total elements to send is passed by the master through argv[1].

    fd = CHECK(open(PIPE_PATH, O_WRONLY));   // Opens the named pipe created by the master.

    /* Fills the data array with random integer values. */
    for (int i = 0; i < MAX; i++)
    {
        data[i] = rand() % 10;
    }

    send_start_time();   // Starts the timer, function defined in timing.c

    /* Loops until all elements have not been send via named pipe. */
    for (int i = 0; i < noelement_to_send; i++)
    {
        CHECK(write(fd, &data[i], sizeof(int)));   // Writes data.

        /* The maximum size of arrays is stored in the variable MAX in the parameters file.
           This piece of code is executed only when the whole array has been send, then it 
           starts again to send numbers from the beginning. */
        if (i == MAX)
        {
            noelement_to_send = noelement_to_send - MAX;   // Decrements the number of elements to send.
            i = 0;                                         // Sets the counter equal to zero.
        }
    }

    logPrint("Producer Named    :Data written\n");   // Prints on log file.

    CHECK(close(fd));                                // Close the file descriptor of the named pipe.

    return 0;
}
