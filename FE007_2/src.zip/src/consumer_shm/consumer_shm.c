/* LIBRARIES */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <time.h>
#include "../parameters/parameters.h"
#include "../timing/timing.c"

FILE *log_file;

/*FUNCTION HEADER*/
void logPrint(char *string);

/*FUNCTION*/
void logPrint(char *string)
{
    /* Function to print on log file adding time stamps. */
    time_t ltime = time(NULL);
    fprintf(log_file, "%.19s: %s", ctime(&ltime), string);
    fflush(log_file);
}

/*MAIN*/
int main(int argc, char *argv[])
{
    int data;     // This variable will contain the read data
    int B[MAX];   // Array of data to fill
    int tail = 0; // Tail of circular buffer

    int j = 0;
    log_file = fopen("../log_file/log.txt", "a");

    int total_elements = atoi(argv[1]);
    int noelement_to_read = total_elements;

    /*Opening the shared memory*/
    int shm_fd = CHECK(shm_open(SHM_NAME, O_RDONLY, 0666));

    /*  the mmap() funciton establishes a memory-mapped file containing
        the shared memory object. It also returns a pointer to the memory-mapped
        file that is used for accessing the shared memory object. */
    void *shm_ptr = mmap(NULL, CBUFFER_SIZE, PROT_READ, MAP_SHARED, shm_fd, 0);

    /*Opening semaphores*/
    sem_t *mutex = sem_open(SNAME_MUTEX, 0);
    sem_t *NotFull = sem_open(SNAME_NOTFULL, 0);
    sem_t *NotEmpty = sem_open(SNAME_NOTEMPTY, 0);

    /*Checking the sem_open funciton execution*/
    if (mutex == SEM_FAILED)
    {
        perror("Failed to open mutex semaphore\n");
        exit(-1);
    }
    if (NotFull == SEM_FAILED)
    {
        perror("Failed to open NotFull semaphore\n");
        exit(-1);
    }
    if (NotEmpty == SEM_FAILED)
    {
        perror("Failed to open NotEmpty semaphore\n");
        exit(-1);
    }

    for (int i = 0; i < noelement_to_read; i++)
    {
        // Decrement the semaphore value.
        CHECK(sem_wait(NotEmpty)); // Checking if the circular buffer is full
        CHECK(sem_wait(mutex));    // Read-write synchronization

        // Reading data from the shared memory
        memcpy(&data, &(((int *)shm_ptr)[tail]), sizeof(int));

        // Filling the data array
        B[i] = data;

        tail = (tail + 1) % BUFFER_NOELEMENT;

        // Increment the semaphore value.
        CHECK(sem_post(mutex));
        CHECK(sem_post(NotFull));

        if (j % (total_elements / 100) == 0)
        {
            // Graphical loading bar
            loading_bar(j, total_elements);
        }

        /*  We established a maximum array size of 250000 elements. Therefore we send
            the same data of the same array multiple times. When the whole array has
            been sent we make the for loop restart until all the data are sent.    */
        if (i == MAX)
        {
            noelement_to_read = noelement_to_read - MAX;
            i = 0;
        }

        j++;
    }

    send_end_time(); // End time instant

    logPrint("Consumer Shared Memory    :Data read\n");

    sleep(1);

    CHECK(close(shm_fd));

    return 0;
}
