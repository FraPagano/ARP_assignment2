/* LIBRARIES */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <time.h>
#include "../parameters/parameters.h"    // Library for paramethers.
#include "../timing/timing.c"            // Functions for timing and printing on log file.

/* MAIN */
int main(int argc, char *argv[])
{
    int data;       // This variable will contain the read data.
    int B[MAX];     // Array of data to fill.
    int tail = 0;   // Tail of circular buffer.
    int j = 0;      // Incremental variable for the loading bar.

    int total_elements = atoi(argv[1]);       // The number of total elements is passed by the master through argv[1].
    int shm_size = atoi(argv[2]);             // The size of the shared memory is passed by the master through argv[2].
    int noelement_to_read = total_elements;   // Number of elements still to be read.

    int shm_fd = CHECK(shm_open(SHM_NAME, O_RDWR, 0666));   // Opens the shared memory created by the master.

    int *shm_ptr = (int *)mmap(NULL, shm_size, PROT_READ, MAP_SHARED, shm_fd, 0);   // Maps the shared memory.

    /* Opens semaphores. */
    sem_t *mutex = sem_open(SNAME_MUTEX, 0);
    sem_t *NotFull = sem_open(SNAME_NOTFULL, 0);
    sem_t *NotEmpty = sem_open(SNAME_NOTEMPTY, 0);

    /* Checks the sem_open funciton execution. */
    if (mutex == SEM_FAILED)
    {
        perror("Failed to open mutex semaphore\n");
        exit(-1);
    }
    if (NotFull == SEM_FAILED)
    {
        perror("Failed to open NotFull semaphore\n");
        exit(-1);
    }
    if (NotEmpty == SEM_FAILED)
    {
        perror("Failed to open NotEmpty semaphore\n");
        exit(-1);
    }

    /* Loops until all elements have not been read from the shared memory. */
    for (int i = 0; i < noelement_to_read; i++)
    {
        CHECK(sem_wait(NotEmpty));   // Decrements the value of the NotEmpty semaphore: there is something to read or the process is blocked.
        CHECK(sem_wait(mutex));      // Takes the mutex for the read-write synchronization.
        
        data = shm_ptr[tail];        // Reads data from the tail of the shared memory.

        CHECK(sem_post(mutex));      // Releases the mutex for the read-write synchronization.
        CHECK(sem_post(NotFull));    // Increments the value of the NotFull semaphore.

        B[i] = data;                 // Fills the data array.

        /* Change the position of the tail. */
        tail = tail + 1;                  // Increments the tail value.

        if (tail == shm_size / 4) {   // If the tail is at the end of the shared memory.
            tail = 0;                     // Sets the tail to the beginning of the shared memory (zero).
        }

        /* Prints on screen dinamically the loading bar. */
        if (j % (total_elements / 100) == 0)   // Every 1% competed.
        {
            loading_bar(j, total_elements);    // Calls the loading_bar function defined in timing.c
        }

        /* The maximum size of arrays is stored in the variable MAX in the parameters file.
           This piece of code is executed only when the whole array has been read, then it 
           starts again to read from the beginning. */
        if (i == MAX)
        {
            noelement_to_read = noelement_to_read - MAX;   // Decrements the number of elements to read.
            i = 0;                                         // Sets the counter equal to zero.
        }

        j++;
    }

    send_end_time();                                      // Stops the timer, function defined in timing.c

    logPrint("Consumer Shared Memory    :Data read\n");   // Prints on log file.

    loading_bar(total_elements, total_elements);          // Set the loading bar to 100%.

    CHECK(close(shm_fd));                                 // Close the file descriptor of the named pipe.

    return 0;
}
