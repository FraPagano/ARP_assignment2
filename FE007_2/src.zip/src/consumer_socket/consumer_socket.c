/* LIBRARIES */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>
#include <time.h>
#include "../parameters/parameters.h"
#include "../timing/timing.c"

FILE *log_file;
char str[80];

/*FUNCTION HEADER*/
void logPrint(char *string);

/*FUNCTION*/
void logPrint(char *string)
{
    /* Function to print on log file adding time stamps. */
    time_t ltime = time(NULL);
    fprintf(log_file, "%.19s: %s", ctime(&ltime), string);
    fflush(log_file);
}

/*MAIN*/
int main(int argc, char *argv[])
{
    // sockfd and newsockfd are file descriptors. portno stores the port number on which the server accepts connections
    int sockfd, newsockfd, clilen, B[MAX], data;

    int j = 0;
    log_file = fopen("../log_file/log.txt", "a");

    // portno is the variable containing the used port number for socket connection
    int portno;
    int total_elements = atoi(argv[1]);
    int noelement_to_read = total_elements;

    // The variable serv_addr will contain the address of the server, and cli_addr will contain the
    // address of the client which connects to the server
    struct sockaddr_in serv_addr, cli_addr; // This structure is defined in <netinet/in.h>

    /*  The socket() system call creates a new socket. We created a stream socket in the
        Internet domain. The third argument is the protocol. If this argument is zero the operating
        system will choose the most appropriate protocol. It will choose TCP in this case. */
    sockfd = CHECK(socket(AF_INET, SOCK_STREAM, 0));

    // setting all values of "serv_addr" to zero.
    bzero((char *)&serv_addr, sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;

    // "sin_port" field contains the port number. By setting this value to zero we will let the OS choose an available port.
    serv_addr.sin_port = 0;

    // This field contains the IP address of the host.
    serv_addr.sin_addr.s_addr = INADDR_ANY;

    // The bind() system call binds a socket to an address, in this case the address of the current host and port
    // number on which the server will run.
    CHECK(bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)));

    // Listening on the socket for connections.
    CHECK(listen(sockfd, 5));

    socklen_t len = sizeof(serv_addr);

    // Getting the port number chosen by the OS
    CHECK(getsockname(sockfd, (struct sockaddr *)&serv_addr, &len));

    printf(BHBLU "Used port number: %d" RESET "\n", ntohs(serv_addr.sin_port));
    sprintf(str, "Consumer Socket    :Used port number: %d \n", ntohs(serv_addr.sin_port));
    logPrint(str);
    portno = htons(serv_addr.sin_port);
    int fd_port = CHECK(open(PORT_PATH, O_WRONLY));

    // Sending the port number
    CHECK(write(fd_port, &portno, sizeof(int)));

    // Block the process until a client correctly connects to the server.
    clilen = sizeof(cli_addr);
    newsockfd = CHECK(accept(sockfd, (struct sockaddr *)&cli_addr, &clilen));

    // Note that we would only get to this point after a client has successfully connected to our server. We can now
    // reads from the socket.
    for (int i = 0; i < noelement_to_read; i++)
    {
        // Reading data...
        CHECK(read(newsockfd, &data, sizeof(int)));

        if (j % (total_elements / 100) == 0)
        {
            // Graphical loading bar
            loading_bar(j, total_elements);
        }

        // Filling the data array
        B[i] = data;

        /*  We established a maximum array size of 250000 elements. Therefore we read
            the same data of the same array multiple times. When the whole array has
            been read we make the for loop restart until all the data are read.    */
        if (i == MAX)
        {
            noelement_to_read = noelement_to_read - MAX;
            i = 0;
        }

        j++;
    }

    send_end_time(); // End time instant

    logPrint("Producer Socket    : Data read\n");

    sleep(1);

    CHECK(close(fd_port));
    CHECK(close(sockfd));

    return 0;
}