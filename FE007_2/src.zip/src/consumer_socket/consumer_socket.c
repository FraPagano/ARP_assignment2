/* LIBRARIES */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>
#include <time.h>
#include "../parameters/parameters.h"    // Library for paramethers.
#include "../timing/timing.c"            // Functions for timing and printing on log file.

/* MAIN */
int main(int argc, char *argv[])
{
    int sockfd, newsockfd;                    // File descriptors.
    int clilen, data;                         // Length of client address and variable for the read data.
    int portno;                               // Used port number for socket connection.
    struct sockaddr_in serv_addr, cli_addr;   // Address of the server and address of the client.
    int B[MAX];                               // Array of data to fill.
    char str[80];                             // Buffer to print on log file.
    int j = 0;                                // Incremental variable for the loading bar.

    int total_elements = atoi(argv[1]);       // The number of total elements is passed by the master through argv[1].
    int noelement_to_read = total_elements;   // Number of elements still to be read.

    sockfd = CHECK(socket(AF_INET, SOCK_STREAM, 0));   // Creates a new socket.

    /* Initialize the serv_addr struct. */
    bzero((char *)&serv_addr, sizeof(serv_addr));      // Sets all arguments of serv_addr to zero.
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = 0;
    serv_addr.sin_addr.s_addr = INADDR_ANY;

    CHECK(bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)));   // Binds the socket to serv_addr.

    CHECK(listen(sockfd, 5));   // Listens on the socket for connections.

    socklen_t len = sizeof(serv_addr);

    CHECK(getsockname(sockfd, (struct sockaddr *)&serv_addr, &len));   // Gets the port number chosen by the OS.

    /* Prints on the terminal and on the log file the used port. */
    printf(BHBLU "Used port number: %d" RESET "\n", ntohs(serv_addr.sin_port));
    sprintf(str, "Consumer Socket    :Used port number: %d \n", ntohs(serv_addr.sin_port));
    logPrint(str);

    portno = htons(serv_addr.sin_port);   // Stores the port number in network byte order.

    /* Sends the port number to the producer via named pipe. */
    int fd_port = CHECK(open(PORT_PATH, O_WRONLY));   // Opens the named pipe. 
    CHECK(write(fd_port, &portno, sizeof(int)));      // Writes in the named pipe the port number.

    /* Block the process until a client correctly connects. */
    clilen = sizeof(cli_addr);
    newsockfd = CHECK(accept(sockfd, (struct sockaddr *)&cli_addr, &clilen));

    /* Loops until all elements have not been read from the socket. */
    for (int i = 0; i < noelement_to_read; i++)
    {
        CHECK(read(newsockfd, &data, sizeof(int)));   // Reads data.

        /* Loading bar. */
        if (j % (total_elements / 100) == 0)
        {
            loading_bar(j, total_elements);
        }

        B[i] = data;   // Fills the data array.

        /* The maximum size of arrays is stored in the variable MAX in the parameters file.
           This piece of code is executed only when the whole array has been read, then it 
           starts again to read from the beginning. */
        if (i == MAX)
        {
            noelement_to_read = noelement_to_read - MAX;   // Decrements the number of elements to read.
            i = 0;                                         // Sets the counter equal to zero.
        }

        j++;
    }

    send_end_time();                                // Stops the timer, function defined in timing.c

    logPrint("Producer Socket    : Data read\n");   // Prints on log file.

    loading_bar(total_elements, total_elements);    // Set the loading bar to 100%.

    /* Close file descriptors. */
    CHECK(close(fd_port));
    CHECK(close(sockfd));

    return 0;
}
