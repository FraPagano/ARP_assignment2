/* LIBRARIES */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <time.h>
#include "../parameters/parameters.h"
#include "../timing/timing.c"

/* MAIN */
int main(int argc, char *argv[])
{
    int sockfd;                     // File descriptor.
    int data[MAX];                  // Array of data to send.
    struct sockaddr_in serv_addr;   // Address of the server.
        int portno;                 // Used port number for socket connection.

    struct hostent *server = gethostbyname(argv[1]);   // The name of a host on the Internet is passed by the master through argv[1], in this case is the computer itself.
    int noelement_to_send = atoi(argv[2]);             // The number of total elements to send is passed by the master through argv[2].

    /* Receives the port number from the consumer via named pipe. */
    int fd_port = CHECK(open(PORT_PATH, O_RDONLY));    // Opens the named pipe. 
    CHECK(read(fd_port, &portno, sizeof(int)));        // Reads from the named pipe the port number.

    sockfd = CHECK(socket(AF_INET, SOCK_STREAM, 0));   // Creates a new socket.

    /* Initialize the serv_addr struct. */
    bzero((char *)&serv_addr, sizeof(serv_addr));      // Sets all arguments of serv_addr to zero.
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
    serv_addr.sin_port = htons(portno);

    CHECK(connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)));   // Connects to the server.

    /* Fills the data array with random integer values. */
    for (int i = 0; i < MAX; i++)
    {
        data[i] = rand() % 10;
    }

    send_start_time();   // Starts the timer, function defined in timing.c

    /* Loops until all elements have not been send via named pipe. */
    for (int i = 0; i < noelement_to_send; i++)
    {
        CHECK(write(sockfd, &data[i], sizeof(int)));   // Writes data.

        /* The maximum size of arrays is stored in the variable MAX in the parameters file.
           This piece of code is executed only when the whole array has been send, then it 
           starts again to send numbers from the beginning. */
        if (i == MAX)
        {
            noelement_to_send = noelement_to_send - MAX;   // Decrements the number of elements to send.
            i = 0;                                         // Sets the counter equal to zero.
        }
    }

    logPrint("Producer Socket    : Data written\n");   // Prints on log file.

    /* Close file descriptors. */
    CHECK(close(fd_port));
    CHECK(close(sockfd));
    
    return 0;
}
