/* LIBRARIES */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <time.h>
#include <signal.h>
#include "../parameters/parameters.h" // Library for paramethers.
#include "../timing/timing.c"         // Functions for timing and printing on log file.

/* GLOBAL VARIABLES */
int pid_producer;
int pid_consumer;
int noelement; // Number of integers to transfer.
float dataMB;  // Number of MB to transfer
char str[80];  // Buffer to print on log file.

/* FUNCTIONS HEADERS */
int spawn(const char *program, char **arg_list);
void create_fifo(const char *name);
int interpreter();
double closing_function();
void check_prod_cons(int prod_status, int cons_status);

/* FUNCTIONS */
int spawn(const char *program, char **arg_list)
{
    /* Function to generate a child process, it returns the PID of the child. */

    pid_t child_pid = fork();
    if (child_pid != 0) // Father process.
        return child_pid;

    else
    { // Child process.
        CHECK(execvp(program, arg_list));
        perror("exec failed"); // If it's executed, an error occurred.
        return -4;
    }
}

void create_fifo(const char *name)
{
    /* Function to generate a named pipe with 0666 permission. */

    mkfifo(name, 0666);
}

int interpreter()
{
    /* This function implements the User Interface of the program.
       It asks for the desired data trasmission modality, the number of data to send and implements the exit command.
       It also checks for the correctness of the pressed key, otherwise it prints again the same request.  */

    int c; // Command received by the user.

    while (1)
    {
        /* Print the first request: data transmission modality. */
        printf(BHWHT "Please, choose the data transmission modality: " RESET "\n");
        printf(BHBLU " [1] Named pipe " RESET "\n" BHYEL " [2] Unnamed pipe " RESET "\n" BHCYN " [3] Sockets " RESET "\n" BHMAG " [4] Shared memory " RESET "\n" BHRED " [5] For exiting" RESET "\n");
        fflush(stdout);

        /* Gets the input command. */
        scanf(" %d", &c);

        if (c == 1) // Command for NAMED PIPE.
        {
            printf(BHGRN "NAMED PIPE selected, " RESET);
            logPrint("Master    : '1' keyboard key pressed\n");
            fflush(stdout);
            break;
        }
        else if (c == 2) // Command for UNNAMED PIPE.
        {
            printf(BHGRN "UNNAMED PIPE selected, " RESET);
            logPrint("Master    : '2' keyboard key pressed\n");
            break;
        }
        else if (c == 3) // Command for SOCKETS.
        {
            printf(BHGRN "SOCKETS selected, " RESET);
            logPrint("Master    : '3' keyboard key pressed\n");
            break;
        }
        else if (c == 4) // Command for SHARED MEMORY.
        {
            printf(BHGRN "SHARED MEMORY selected, " RESET);
            logPrint("Master    : '4' keyboard key pressed\n");
            break;
        }
        else if (c == 5) // Command for EXIT.
        {
            printf(BHRED "Exiting... " BHYEL "You can review the performed tests in ./src/tests/performed_tests.txt " RESET " \n");
            logPrint("Master    : '5' keyboard key pressed\n");
            return c;
        }
        else // The pressed key is none of the commands.
        {
            printf("Please, use the commands above.\n");
            logPrint("Master    : wrong command pressed\n");
            fflush(stdout);
            fgetc(stdin);
        }
    } // End of while.

    while (1)
    {
        /* Print the second request: amount of data to send. */
        printf(BHGRN "Insert how many MB do you want to send: [float < 100] " RESET "\n");
        fflush(stdout);

        /* Gets the amount of data. */
        scanf("%f", &dataMB);

        sprintf(str, "Master    : %f MB inserted\n", dataMB);
        logPrint(str);

        if (dataMB > 100) // 100 MB is the maximum selectable quantity.
        {
            printf(BHRED "The number must be less then or equal 100.\n" RESET);
        }
        else
        {
            /* Converts the amount of data from MB to number of integers, one MB is 250000 integers. */
            noelement = dataMB * 250000; // Fill the global variable noelement.
            break;
        }
    } // End of while.

    return c;
}

void check_prod_cons(int prod_status, int cons_status)
{
    /* This function checks the producer and consumer return values. */

    if (prod_status != 0 || cons_status != 0) // If one returned value is different from zero.
    {

        printf(BHRED "\n An error occurred, killing all processes..." RESET "\n");
        logPrint("An error occurred, killing all processes...\n");

        /* Prints PIDs on the terminal. */
        printf(BHCYN "\n\nProducer " BHRED "(PID = %d) " BHCYN " exited with status " BHRED "%d" RESET "\n", pid_producer, prod_status);
        printf(BHCYN "Consumer " BHRED "(PID = %d)" BHCYN " exited with status " BHRED "%d" RESET "\n", pid_consumer, cons_status);

        /* Prints PIDs on the log file. */
        sprintf(str, "Master    : Producer (PID = %d) exited with status %d\n", pid_producer, prod_status);
        logPrint(str);
        sprintf(str, "Master    : Consumer (PID = %d) exited with status %d\n", pid_consumer, cons_status);
        logPrint(str);

        /* Kill all processes: producer, consumer and master. */
        kill(pid_producer, SIGKILL);
        kill(pid_consumer, SIGKILL);
        kill(getpid(), SIGKILL);
    }
}

double closing_function()
{
    /* This function is called when the two child processes are exchanging data.
       It waits for the termination of the producer and the consumer child processes and checks their return values.
       It also reads the starting and the ending time of the data transmission from prepared named pipes. */

    int prod_status, cons_status;   // Producer and consumer exit values.
    int fd_time_start, fd_time_end; // File descriptors for named pipes to get starting and ending time.
    double start, end;              // Starting and ending time.

    /* Opens the named pipes. */
    fd_time_start = CHECK(open(TSTART_PATH, O_RDONLY));
    fd_time_end = CHECK(open(TEND_PATH, O_RDONLY));

    /* Waits for the termination of child processes. */
    CHECK(waitpid(pid_producer, &prod_status, 0)); // Waits the producer child.
    CHECK(waitpid(pid_consumer, &cons_status, 0)); // Waits the consumer child.

    /* Reads the starting and the ending time of the data transmission. */
    CHECK(read(fd_time_start, &start, sizeof(start))); // Reads the start time instant.
    CHECK(read(fd_time_end, &end, sizeof(end)));       // Reads the end time instant.

    /* Closes the named pipes. */
    CHECK(close(fd_time_start));
    CHECK(close(fd_time_end));

    /* Checks for producer and consumer return values. */
    check_prod_cons(prod_status, cons_status);

    /* Prints PIDs on the log file. */
    sprintf(str, "Master    : Producer (PID = %d) exited with status %d\n", pid_producer, prod_status);
    logPrint(str);
    sprintf(str, "Master    : Consumer (PID = %d) exited with status %d\n", pid_consumer, cons_status);
    logPrint(str);

    /* Prints PIDs on the terminal. */
    printf(BHCYN "\n\nProducer " BHYEL " (PID = %d)" BHCYN " exited with status " BHGRN "%d" RESET "\n", pid_producer, prod_status);
    printf(BHCYN "Consumer " BHYEL "(PID = %d) " BHCYN "exited with status " BHGRN " %d" RESET "\n", pid_consumer, cons_status);

    /*Returns the time interval taken by the data transmission. */
    return (end - start);
}

/* MAIN */
int main()
{
    /* Opens tests file and creates the log file. */
    FILE *tests = fopen("../tests/tests_performed.txt", "w");  // This '.txt' file contains a short recap of the performed tests.
    FILE *log_file_create = fopen("../log_file/log.txt", "w"); // Creates log file.

    if (!log_file_create)
    {
        // Error management for fopen.
        perror("Error opening file");
        return -2; // return value put at -2 just to avoid confusing with the CHECK function control.
    }

    logPrint("Master    : Log file created by master process.\n");

    /* Prints the Master process ID on the terminal. */
    printf(BHWHT "\nMaster process ID: " BHYEL "%d" RESET "\n\n", getpid());

    /* Prints the Master process ID on the log file. */
    sprintf(str, "Master process ID: %d\n", getpid());
    logPrint(str);

    /* Creates named pipes for timing. */
    create_fifo(TSTART_PATH); // fifo for start time instant.
    create_fifo(TEND_PATH);   // fifo for end time instant.

    while (1)
    {
        /* Calls the interpreter function to ask the user the data transmission modality and the amount of data. */
        int command = interpreter();

        /*The number of element to transfer will be passed through the argv[] array to each process*/
        char noelement_char[20];
        sprintf(noelement_char, "%d", noelement);

        if (command == 1) // NAMED PIPE selected.
        {
            logPrint("Master    : Named pipe selected\n");

            /* Creates the named pipe. */
            create_fifo(PIPE_PATH);

            printf(BHBLU "Sending data..." RESET "\n");
            fflush(stdout);

            logPrint("Master    : Creating producer and consumer child processes\n");

            /* Executes both the consumer and the producer child processes.
               argv[1] number of elements to send. */

            char *arg_list_producer_named[] = {"./producer_named", noelement_char, (char *)NULL};
            pid_producer = spawn("./producer_named", arg_list_producer_named);

            char *arg_list_consumer_named[] = {"./consumer_named", noelement_char, (char *)NULL};
            pid_consumer = spawn("./consumer_named", arg_list_consumer_named);

            /* Calls the closing function to wait for child processes. */
            double time = closing_function(); // Stores the taken time interval in the 'time' variable

            printf("\n" BHWHT "---> NAMED PIPE took " BHYEL "%f" BHWHT " milliseconds to transfer " BHYEL "%f MB." RESET "\n \n", time, dataMB);

            fprintf(tests, "---> NAMED PIPE took %f milliseconds to transfer %f MB.\n \n", time, dataMB);

            sprintf(str, "Master    : NAMED PIPE took %f milliseconds to transfer %f MB\n", time, dataMB);
            logPrint(str);

            CHECK(unlink(PIPE_PATH)); // Remove the named pipe.
        }

        if (command == 2) // UNNAMED PIPE selected.
        {
            int fd_unnamed[2];      // File descriptors to read and write on the unnamed pipe.
            char input_fd_char[20]; // Buffer for passing the file descriptor through argv.

            CHECK(pipe(fd_unnamed)); // Creates the unnamed pipe.

            printf(BHBLU "Sending data..." RESET "\n");
            fflush(stdout);

            logPrint("Master    : Creating producer and consumer child processes\n");

            /* Executes both the consumer and the producer child processes.
               argv[1] number of elements to send.
               argv[2] file descriptor of the unnamed pipe. */

            sprintf(input_fd_char, "%d", fd_unnamed[1]);
            char *arg_list_producer[] = {"./producer_unnamed", noelement_char, input_fd_char, (char *)NULL};
            pid_producer = spawn("./producer_unnamed", arg_list_producer);

            sprintf(input_fd_char, "%d", fd_unnamed[0]);
            char *arg_list_consumer[] = {"./consumer_unnamed", noelement_char, input_fd_char, (char *)NULL};
            pid_consumer = spawn("./consumer_unnamed", arg_list_consumer);

            /* Calls the closing function to wait for child processes. */
            double time = closing_function(); // Stores the taken time interval in the 'time' variable

            printf(BHWHT "\n---> UNNAMED PIPE took" BHYEL " %f " BHWHT " milliseconds to transfer" BHYEL " %f MB." RESET "\n \n", time, dataMB);

            fprintf(tests, "---> UNNAMED PIPE took %f milliseconds to transfer %f MB.\n \n", time, dataMB);

            sprintf(str, "Master    : Unnamed pipe took %f milliseconds to transfer %f MB\n", time, dataMB);
            logPrint(str);
        }

        if (command == 3) // SOCKET selected.
        {
            create_fifo(PORT_PATH); // Creates a named pipe to exchange the port number between child processes.

            printf(BHBLU "OS is searching for a free port" RESET "\n");
            printf(BHBLU "Sending data..." RESET "\n");
            fflush(stdout);

            logPrint("Master    : Creating producer and consumer child processes\n");

            /* Executes both the consumer and the producer child processes. */

            /* argv[1] number of elements to send. */
            char *arg_list_consumer[] = {"./consumer_socket", noelement_char, (char *)NULL};
            pid_consumer = spawn("./consumer_socket", arg_list_consumer);

            /* argv[1] name of a host on the Internet, in this case the computer itself.
               argv[2] number of elements to send. */
            char *arg_list_producer[] = {"./producer_socket", "localhost", noelement_char, (char *)NULL};
            pid_producer = spawn("./producer_socket", arg_list_producer);

            /* Calls the closing function to wait for child processes. */
            double time = closing_function(); // Stores the taken time interval in the 'time' variable

            printf(BHWHT "\n---> SOCKET took " BHYEL "%f" BHWHT " milliseconds to transfer" BHYEL " %f MB." RESET "\n \n", time, dataMB);

            fprintf(tests, "---> SOCKET took %f milliseconds to transfer %f MB.\n \n", time, dataMB);

            sprintf(str, "Master    : SOCKET took %f milliseconds to transfer %f MB\n", time, dataMB);
            logPrint(str);

            CHECK(unlink(PORT_PATH));
        }
        if (command == 4) // SHARED MEMORY selected.
        {
            printf(BHBLU "Sending data..." RESET "\n");
            fflush(stdout);

            /* Opens the shared memory space. */
            int shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
            ftruncate(shm_fd, SIZE);

            /* Creates and opens the semaphores. */
            sem_t *mutex = sem_open(SNAME_MUTEX, O_CREAT, 0644, 1);
            sem_t *NotFull = sem_open(SNAME_NOTFULL, O_CREAT, 0644, BUFFER_NOELEMENT - 1);
            sem_t *NotEmpty = sem_open(SNAME_NOTEMPTY, O_CREAT, 0644, 0);

            logPrint("Master    : Creating producer and consumer child processes\n");

            /* Executes both the consumer and the producer child processes.
               argv[1] number of elements to send. */

            char *arg_list_producer[] = {"./producer_shm", noelement_char, (char *)NULL};
            pid_producer = spawn("./producer_shm", arg_list_producer);

            char *arg_list_consumer[] = {"./consumer_shm", noelement_char, (char *)NULL};
            pid_consumer = spawn("./consumer_shm", arg_list_consumer);

            /* Calls the closing function to wait for child processes. */
            double time = closing_function(); // Stores the taken time interval in the 'time' variable

            printf(BHWHT "\n---> SHARED MEMORY took " BHYEL "%f" BHWHT " milliseconds to transfer" BHYEL " %f MB" RESET ".\n \n", time, dataMB);

            fprintf(tests, "---> SHARED MEMORY took %f milliseconds to transfer %f MB.\n \n", time, dataMB);

            sprintf(str, "Master    : SHARED MEMORY took %f milliseconds to transfer %f MB\n", time, dataMB);
            logPrint(str);

            /* Removes the shared memory space. */
            CHECK(shm_unlink(SHM_NAME));

            /*Closes semaphores. */
            CHECK(sem_close(mutex));
            CHECK(sem_close(NotFull));
            CHECK(sem_close(NotEmpty));

            /* Removes semaphores. */
            CHECK(sem_unlink(SNAME_MUTEX));
            CHECK(sem_unlink(SNAME_NOTFULL));
            CHECK(sem_unlink(SNAME_NOTEMPTY));

            logPrint("Master    : Shared memory space unlinked\n");
            logPrint("Master    : Semaphores unlinked\n");
        }

        if (command == 5) // EXIT COMMAND selected.
        {
            logPrint("Master    : Exiting.\n");
            break;
        }
    } // End of while.

    /* Removes named pipes used for the timing of processes. */
    CHECK(unlink(TSTART_PATH));
    CHECK(unlink(TEND_PATH));

    logPrint("Master    : Master is termitating \n");

    return 0;
}