/* LIBRARIES */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include "../parameters/parameters.h"    // Library for paramethers.
#include "../timing/timing.c"            // Functions for timing and printing on log file.

/*MAIN*/
int main(int argc, char *argv[])
{
    int data;     // This variable will contain the read data.
    int fd;       // File descriptor for named pipe.
    int B[MAX];   // Array of data to fill.
    int j = 0;    // Incremental variable for the loading bar.

    int total_elements = atoi(argv[1]);       // The number of total elements is passed by the master through argv[1].
    int noelement_to_read = total_elements;   // Number of elements still to be read.

    fd = CHECK(open(PIPE_PATH, O_RDONLY));    // Opens the named pipe created by the master.

    /* Loops until all elements have not been read. */
    for (int i = 0; i < noelement_to_read; i++)
    {
        CHECK(read(fd, &data, sizeof(int)));   // Reads data.

        /* Loading bar. */
        if (j % (total_elements / 100) == 0)
        {
            loading_bar(j, total_elements);
        }

        B[i] = data;   // Fills the data array.

        /* The maximum size of arrays is stored in the variable MAX in the parameters file.
           Therefore it reads and writes the same data of the same array multiple times. 
           This piece of code is executed only when the whole array has been read. */
        if (i == MAX)
        {
            noelement_to_read = noelement_to_read - MAX;   // Decrements the number of elements to read.
            i = 0;                                         // Sets the counter equal to zero.
        }

        j++;
    }

    send_end_time();                               // Stops the timer.

    logPrint("Consumer Named    :Data read\n");    // Prints on log file.

    loading_bar(total_elements, total_elements);   // Set the loading bar to 100%.

    sleep(1);

    CHECK(close(fd));                              // Close the file descriptor of the named pipe.

    return 0;
}