/* LIBRARIES */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include "../parameters/parameters.h"
#include "../timing/timing.c"

/*MAIN*/
int main(int argc, char *argv[])
{
    int data;   // This variable will contain the read data
    int fd;     // File descriptor
    int B[MAX]; // Array of data to fill
    int j = 0;

    int total_elements = atoi(argv[1]);
    int noelement_to_read = total_elements;

    fd = atoi(argv[2]);

    for (int i = 0; i < noelement_to_read; i++)
    {
        // Reading data...
        CHECK(read(fd, &data, sizeof(int)));

        if (j % (total_elements / 100) == 0)
        {
            // Graphical loading bar
            loading_bar(j, total_elements);
        }

        // Filling the data array
        B[i] = data;

        /*  We established a maximum array size of 250000 elements. Therefore we read
            the same data of the same array multiple times. When the whole array has
            been read we make the for loop restart until all the data are read.    */
        if (i == MAX)
        {
            noelement_to_read = noelement_to_read - MAX;
            i = 0;
        }
        j++;
    }

    send_end_time(); // End time instant

    logPrint("Producer Unnamed    :Data read\n");

    loading_bar(total_elements, total_elements);

    sleep(1);

    CHECK(close(fd));

    return 0;
}