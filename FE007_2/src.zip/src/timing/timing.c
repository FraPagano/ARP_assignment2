/* LIBRARIES */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <string.h>

#include "../parameters/parameters.h"

void send_start_time()
{
    // This funciton's aim is to send the starting time instant of the transmission of data..

    struct timespec start;

    // Get current value of clock CLOCK_ID and store it in "start".
    CHECK(clock_gettime(CLOCK_REALTIME, &start));

    // Measuring time intervals in milliseconds!
    double time_start = start.tv_sec * 1000 + start.tv_nsec * pow(10, -6);

    // We chose to communicate time instants between processes trough named pipe.
    int fd_time_start = CHECK(open(TSTART_PATH, O_WRONLY));

    // Sending the starting time to the master process.
    CHECK(write(fd_time_start, &time_start, sizeof(time_start)));

    CHECK(close(fd_time_start));
}

void send_end_time()
{
    // This funciton's aim is to send the ending time instant of the transmission of data.

    struct timespec end;

    // Get current value of clock CLOCK_ID and store it in "end".
    CHECK(clock_gettime(CLOCK_REALTIME, &end));

    // Measuring time intervals in milliseconds!
    double time_end = end.tv_sec * 1000 + end.tv_nsec * pow(10, -6);

    // We chose to communicate time instants between processes trough named pipe.
    int fd_time_end = CHECK(open(TEND_PATH, O_WRONLY));

    // Sending the starting time to the master process.
    CHECK(write(fd_time_end, &time_end, sizeof(time_end)));

    CHECK(close(fd_time_end));
}

void loading_bar(int percent, int buf_size)
{

    /*This is a simple graphical feature that we implemented. It is a loading bar that graphically
        represents the progress percentage of the data transmission  */

    const int PROG = 30;
    int num_chars = (percent / (buf_size / 100)) * PROG / 100;
    printf("\r[");
    for (int i = 0; i <= num_chars; i++)
    {
        printf("#");
    }
    for (int i = 0; i < PROG - num_chars - 1; i++)
    {
        printf(" ");
    }
    printf("] %d %% DONE", percent / ((buf_size / 100) + 1));
    fflush(stdout);
}
