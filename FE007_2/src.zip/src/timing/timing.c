/* LIBRARIES */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <string.h>

#include "../parameters/parameters.h"

/* FUNCTION HEADERS */
void send_start_time();
void send_end_time();
void loading_bar(int percent, int buf_size);
void logPrint(char *string);

void send_start_time()
{
    /* This funciton sends to the master the starting time instant of the data's transmission. */

    struct timespec start;

    /* Gets the current value of clock CLOCK_ID and store it in "start". */
    CHECK(clock_gettime(CLOCK_REALTIME, &start));

    /* Converts the time into milliseconds. */
    double time_start = start.tv_sec * 1000 + start.tv_nsec * pow(10, -6);

    /* Opens the named pipe to communicate with the master. */
    int fd_time_start = CHECK(open(TSTART_PATH, O_WRONLY));

    /* Sends the starting time to the master process. */
    CHECK(write(fd_time_start, &time_start, sizeof(time_start)));

    /* Closes the named pipe. */
    CHECK(close(fd_time_start));
}

void send_end_time()
{
    /* This funciton sends to the master the ending time instant of the data's transmission. */

    struct timespec end;

    /* Gets the current value of clock CLOCK_ID and store it in "end". */
    CHECK(clock_gettime(CLOCK_REALTIME, &end));

    /* Converts the time into milliseconds. */
    double time_end = end.tv_sec * 1000 + end.tv_nsec * pow(10, -6);

    /* Opens the named pipe to communicate with the master. */
    int fd_time_end = CHECK(open(TEND_PATH, O_WRONLY));

    /* Sends the starting time to the master process. */
    CHECK(write(fd_time_end, &time_end, sizeof(time_end)));

    /* Closes the named pipe. */
    CHECK(close(fd_time_end));
}

void loading_bar(int percent, int buf_size)
{

    /*This is a simple graphical feature that we implemented. It is a loading bar that graphically
        rapresents the progress percentage of the data transmission.  */

    const int PROG = 30;
    int num_chars = (percent / (buf_size / 100)) * PROG / 100;
    printf("\r[");
    for (int i = 0; i <= num_chars; i++)
    {
        printf("#");
    }
    for (int i = 0; i < PROG - num_chars - 1; i++)
    {
        printf(" ");
    }
    printf("] %d %% DONE", percent / (buf_size / 100));
    fflush(stdout);
}

void logPrint(char *string)
{
    FILE *log_file = fopen("../log_file/log.txt", "a");   // Opens the log file with append modality.
    /* Function to print on log file adding time stamps. */
    time_t ltime = time(NULL);
    fprintf(log_file, "%.19s: %s", ctime(&ltime), string);
    fflush(log_file);
    fclose(log_file);
}
