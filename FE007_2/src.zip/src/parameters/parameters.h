/* CONSTANTS */
#define SIZE 20000                     // Size of the shared memory.
#define BUFFER_NOELEMENT SIZE / 4      // Number of integers inside the shared memory.
#define MAX 250000                     // Maximum numbers of integers stored into data arrays.

/* PATHS AND NAMES */
#define SNAME_MUTEX "/sem_mutex"             // Name of the mutex.         
#define SNAME_NOTFULL "/sem_not_full"        // Name of the NotFull semaphore.
#define SNAME_NOTEMPTY "/sem_not_empty"      // Name of the NotEmpty semaphore.
#define SHM_NAME "/shm"                      // Name of the shared memory.
#define PIPE_PATH "/tmp/pipe_data"           // Path of the named pipe to exchange data.
#define TSTART_PATH "/tmp/pipe_start_time"   // Path of the named pipe to send the starting time to the master process.
#define TEND_PATH "/tmp/pipe_end_time"       // Path of the named pipe to send the ending time to the master process.
#define PORT_PATH "/tmp/fifo_port"           // Path of the named pipe to send the port number in socket transmission.

/* COLORS */
#define RESET "\033[0m"
#define BHBLK "\e[1;90m"
#define BHRED "\e[1;91m"
#define BHGRN "\e[1;92m"
#define BHYEL "\e[1;93m"
#define BHBLU "\e[1;94m"
#define BHMAG "\e[1;95m"
#define BHCYN "\e[1;96m"
#define BHWHT "\e[1;97m"

/* CHECK() tool. By using this methid the code results ligher and cleaner. */
#define CHECK(X) ({int __val = (X); (__val == -1 ? ({fprintf(stdout,"ERROR (" __FILE__ ":%d) -- %s\n",__LINE__,strerror(errno)); exit(-1);-1;}) : __val); })
